package com.example.flutter_ppro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
